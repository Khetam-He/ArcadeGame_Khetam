# Memory Game Project

## Table of Contents

* [Instructions](#instructions)

## Instructions

Here are some instructions to injoy Memory Game:
1- click on the card to show content .
2- if two cards are maching .. wow thats is great .. go ahead and find another matching pairs .
3- if the cards does not matches .. dont wory keep in mind the content of the cards you have opened and try again with another cards. 
4- if you find all the matching pairs .. Congratulation :) you won.
5- if you find all the matching pairs within at most 15 moves you will get 3 stars .
6- if you find all the matching pairs within at most 20 moves you will get 2 stars .
7- if you find all the matching pairs within at most 30 moves you will get 1 stars .


 Hope you enjoy the game :) 
 
 Khetam Hejazi 